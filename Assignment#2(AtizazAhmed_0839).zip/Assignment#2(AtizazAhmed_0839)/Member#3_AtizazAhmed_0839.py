"""
Member 3 - fastText and Embedding Evaluation
Fake Product Review Detection - NLP Assignment 2

Expected input:
    data/cleaned_dataset.csv

Expected models from Member 2:
    saved_models/cbow.model
    saved_models/skipgram.model

Run:
    pip install -r requirements.txt
    python member#3_AtizazAhmed___0839.py

If your cleaned CSV uses a different text-column name, pass:
    python member3_fasttext_evaluation.py --text-column cleaned_text
"""

import argparse
import json
import re
from pathlib import Path

import pandas as pd
from gensim.models import FastText, Word2Vec


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "fake_reviews_cleaned.csv"
MODEL_DIR = BASE_DIR / "saved_models"
OUTPUT_DIR = BASE_DIR / "member3_fasttext_output"

# These are example domain terms. Replace/add words that actually occur
# in your cleaned product-review corpus.
QUERY_WORDS = ["product", "review", "fake", "good", "bad"]

# First pair should be reasonably related; second pair should be unrelated.
SIMILAR_PAIRS = [("good", "great"), ("product", "excellent")]
UNRELATED_PAIRS = [("good", "battery"), ("fake", "shipping")]

# Example analogy: king - man + woman ~= queen.
# This general-language analogy may fail on a small product-review corpus.
ANALOGY = ("good", "bad", "excellent")


def tokenize(text):
    """Basic tokenization; assumes Assignment 1 cleaning is already complete."""
    text = str(text).lower()
    return re.findall(r"\b[a-z0-9]+\b", text)


def load_corpus(csv_path, text_column=None):
    """Load the existing cleaned corpus without applying a new cleaning pipeline."""
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {csv_path}\n"
            "Put your Assignment 1 cleaned CSV at data/cleaned_dataset.csv "
            "or pass --data PATH."
        )

    df = pd.read_csv(csv_path)
    if df.empty:
        raise ValueError("The cleaned dataset is empty.")

    if text_column:
        if text_column not in df.columns:
            raise ValueError(
                f"Column '{text_column}' not found. Available columns: "
                f"{list(df.columns)}"
            )
        selected_column = text_column
    else:
        # Prefer likely text-column names; otherwise select the longest
        # object/string column based on average text length.
        preferred = [
            "cleaned_text", "review", "text", "review_text",
            "content", "processed_text"
        ]
        selected_column = next(
            (c for c in preferred if c in df.columns), None
        )
        if selected_column is None:
            object_columns = df.select_dtypes(include=["object", "string"]).columns
            if len(object_columns) == 0:
                raise ValueError(
                    "No text column found. Pass the correct name with --text-column."
                )
            selected_column = max(
                object_columns,
                key=lambda c: df[c].fillna("").astype(str).str.len().mean()
            )

    sentences = [
        tokenize(value)
        for value in df[selected_column].dropna()
        if str(value).strip()
    ]
    sentences = [sentence for sentence in sentences if sentence]

    if not sentences:
        raise ValueError(f"No usable text found in column '{selected_column}'.")

    print(f"Loaded {len(sentences)} documents from column: {selected_column}")
    print(f"Vocabulary before model training: {len(set(w for s in sentences for w in s))}")
    return sentences, selected_column


def train_fasttext(sentences, model_path):
    """Train FastText on the same corpus used for the Word2Vec models."""
    model = FastText(
        sentences=sentences,
        vector_size=100,
        window=5,
        min_count=1,
        workers=4,
        sg=1,
        epochs=20,
        min_n=3,
        max_n=6
    )
    model.save(str(model_path))
    print(f"FastText model saved: {model_path}")
    return model


def load_word2vec_models():
    """Load the CBOW and Skip-gram models created by Member 2."""
    models = {}
    for label, filename in [
        ("CBOW", "cbow.model"),
        ("Skip-gram", "skipgram.model")
    ]:
        path = MODEL_DIR / filename
        if path.exists():
            models[label] = Word2Vec.load(str(path))
            print(f"Loaded {label}: {path}")
        else:
            print(
                f"WARNING: {path} not found. "
                f"Member 2 must save their model using this filename."
            )
    return models


def get_vectors(model):
    """Return the keyed vectors object for either Word2Vec or FastText."""
    return model.wv


def similar_words(model, word, top_n=5):
    """Get the top-N nearest words; FastText can also infer OOV vectors."""
    vectors = get_vectors(model)
    try:
        return vectors.most_similar(word, topn=top_n)
    except KeyError:
        return None


def cosine_score(model, word1, word2):
    """Calculate cosine similarity when both words are available."""
    vectors = get_vectors(model)
    try:
        return float(vectors.similarity(word1, word2))
    except KeyError:
        return None


def run_probes(models, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    report = []

    # C1: nearest neighbours for meaningful domain words.
    report.append("C1 - TOP SIMILAR WORDS")
    for model_name, model in models.items():
        report.append(f"\n[{model_name}]")
        for word in QUERY_WORDS:
            results = similar_words(model, word, top_n=5)
            if results is None:
                report.append(f"{word}: not in vocabulary")
            else:
                formatted = ", ".join(
                    f"{term} ({score:.3f})" for term, score in results
                )
                report.append(f"{word}: {formatted}")

    # C2: related and unrelated cosine comparisons.
    report.append("\n\nC2 - COSINE SIMILARITIES")
    for model_name, model in models.items():
        report.append(f"\n[{model_name}]")
        for title, pairs in [
            ("Expected related", SIMILAR_PAIRS),
            ("Expected unrelated", UNRELATED_PAIRS)
        ]:
            report.append(f"{title}:")
            for word1, word2 in pairs:
                score = cosine_score(model, word1, word2)
                if score is None:
                    report.append(
                        f"  {word1} / {word2}: unavailable "
                        "(one or both words are not in the model vocabulary)"
                    )
                else:
                    report.append(f"  {word1} / {word2}: {score:.4f}")

    # C3: analogy: a - b + c ~= ?
    report.append("\n\nC3 - WORD ANALOGY")
    a, b, c = ANALOGY
    for model_name, model in models.items():
        vectors = get_vectors(model)
        try:
            result = vectors.most_similar(
                positive=[a, c], negative=[b], topn=5
            )
            formatted = ", ".join(
                f"{word} ({score:.3f})" for word, score in result
            )
            report.append(f"{model_name}: {a} - {b} + {c} -> {formatted}")
        except KeyError:
            report.append(
                f"{model_name}: analogy unavailable because at least one "
                "analogy word is missing from the vocabulary."
            )

    # C4: concise comparison notes to guide the report.
    report.append("\n\nC4 - COUNT-BASED VS LEARNED REPRESENTATIONS")
    report.append(
        "Count-based BoW/TF-IDF usually have one feature per vocabulary term "
        "(or n-gram), produce sparse document vectors, and do not naturally "
        "create vectors for unseen words. Learned Word2Vec vectors are dense "
        "fixed-size word vectors and capture distributional context, but "
        "standard Word2Vec cannot infer a vector for an unseen word. FastText "
        "uses character n-grams, so it can often create a vector for a rare "
        "or unseen/misspelled form from its subword pieces. Results depend "
        "strongly on corpus size and quality."
    )

    report_text = "\n".join(report)
    report_path = output_dir / "member3_results.txt"
    report_path.write_text(report_text, encoding="utf-8")
    print("\n" + report_text)
    print(f"\nResults saved to: {report_path}")

    # Save machine-readable run details as well.
    metadata = {
        "query_words": QUERY_WORDS,
        "similar_pairs": SIMILAR_PAIRS,
        "unrelated_pairs": UNRELATED_PAIRS,
        "analogy": ANALOGY,
        "models_evaluated": list(models.keys())
    }
    (output_dir / "probe_config.json").write_text(
        json.dumps(metadata, indent=4), encoding="utf-8"
    )


def demonstrate_oov(fasttext_model, word2vec_models):
    """
    B4: demonstrate subword behaviour.
    The candidate may be absent from Word2Vec; FastText should still be able
    to construct a vector if it can use known character n-grams.
    """
    candidates = ["batery", "producttt", "reviewz", "qualitty"]
    fast_vectors = fasttext_model.wv

    print("\nB4 - FASTTEXT RARE / MISSPELLED WORD DEMONSTRATION")
    for word in candidates:
        print(f"\nWord: {word}")
        for model_name, model in word2vec_models.items():
            in_vocab = word in model.wv.key_to_index
            print(f"  {model_name}: {'in vocabulary' if in_vocab else 'OOV'}")
        # FastText can normally generate a vector for OOV strings using n-grams.
        try:
            vector = fast_vectors[word]
            print(
                f"  FastText: vector generated (dimension={len(vector)}); "
                f"norm={float((vector ** 2).sum() ** 0.5):.4f}"
            )
        except KeyError:
            print("  FastText: unable to generate a vector for this token.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=DATA_PATH)
    parser.add_argument("--text-column", type=str, default=None)
    args = parser.parse_args()

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    sentences, selected_column = load_corpus(args.data, args.text_column)

    # Member 3 trains and saves FastText.
    fasttext_path = MODEL_DIR / "fasttext.model"
    fasttext_model = train_fasttext(sentences, fasttext_path)

    # Member 2's models are loaded for a fair comparison on the same corpus.
    word2vec_models = load_word2vec_models()
    all_models = dict(word2vec_models)
    all_models["FastText"] = fasttext_model

    demonstrate_oov(fasttext_model, word2vec_models)
    run_probes(all_models, OUTPUT_DIR)

    print("\nMember 3 tasks completed.")
    print(f"Dataset text column used: {selected_column}")
    print(f"FastText model: {fasttext_path}")
    print(f"Evaluation output: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
