import argparse
import os
import pandas as pd
from gensim.models import Word2Vec

PARAMS = dict(
    vector_size=100,
    window=5,
    min_count=2,
    epochs=20,
    workers=1,
    seed=42,
)


def load_sentences(path, col):
    df = pd.read_csv(path)
    return [str(t).split() for t in df[col].dropna()]


def train(sentences, sg):
    return Word2Vec(sentences=sentences, sg=sg, **PARAMS)


def show_neighbours(model, name, words, topn=5):
    print(f"\n--- {name}: top-{topn} neighbours ---")
    for w in words:
        if w in model.wv:
            sims = ", ".join(f"{x} ({s:.2f})" for x, s in model.wv.most_similar(w, topn=topn))
            print(f"  {w}: {sims}")
        else:
            print(f"  {w}: not in vocabulary")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--col", default="clean_text")
    ap.add_argument("--probe", nargs="*", default=[])
    ap.add_argument("--out", default="models")
    args = ap.parse_args()

    sentences = load_sentences(args.data, args.col)
    n_tokens = sum(len(s) for s in sentences)
    print(f"Documents: {len(sentences)} | tokens: {n_tokens}")
    if n_tokens < 100_000:
        print("NOTE: small corpus - interpret similarities cautiously.")

    print("\nHyperparameters (record these in the report):")
    for k, v in PARAMS.items():
        print(f"  {k} = {v}")

    cbow = train(sentences, sg=0)
    skip = train(sentences, sg=1)
    print(f"\nVocabulary size (after min_count): CBOW={len(cbow.wv)}, Skip-gram={len(skip.wv)}")

    os.makedirs(args.out, exist_ok=True)
    cbow.save(os.path.join(args.out, "w2v_cbow.model"))
    skip.save(os.path.join(args.out, "w2v_skipgram.model"))
    print(f"Saved models to {args.out}/")

    if args.probe:
        show_neighbours(cbow, "CBOW", args.probe)
        show_neighbours(skip, "Skip-gram", args.probe)
